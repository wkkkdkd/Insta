# Security Policy

## Reporting a Vulnerability

Please report a bug or a vulnerability at the issues section, by creating a new issue and describing with as much details as possible.

You can also report a vulnerability by sending us an email at <a href="mailto:new92github@gmail.com">this email address</a>.

Tip: Include screenshots, the OS (Operating System) you are using, etc. in order to fix it with the best way possible !
