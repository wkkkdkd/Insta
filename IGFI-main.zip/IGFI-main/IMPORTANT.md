# ⚠️IMPORTANT⚠️

**Although it's not bounding, it's recommended to include the session file in the arguments passing, in order to avoid program interruptions**

**It's suggested to use IGFI with root privileges in order to avoid possible program interruptions.**

**Use IGFI every 2-3 days in order for your account not to get suspended or eved blocked !**
